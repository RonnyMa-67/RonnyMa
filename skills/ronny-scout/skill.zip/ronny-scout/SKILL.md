---
name: ronny-scout
description: Research and qualify multilingual B2B sales leads from Meta/CRM exports, pasted tables and event forms. Use for Ronny Scout A–J exports, Meta lead reconciliation, product-specific Excel tabs, business due diligence and safe CRM appends. Preserve original buying intent and source IDs, write grounded company profiles and actionable follow-up, and export with filters, WhatsApp links and evidence notes. Works with native AI browsing and file tools.
---

# Ronny Scout

Produce **commercially useful**, source-aware B2B lead intelligence and correctly aligned spreadsheets. This skill is public and vendor-neutral; never embed private client data or a specific employer's product catalog.

## Zero-API native mode

- **Start immediately after installation:** Load the user's CSV/XLSX/Markdown leads or pasted records and follow this skill. Do not ask for API keys, subscriptions, custom integrations, database configuration or deployment. An AI's own browsing, document and spreadsheet tools may be used when available.
- **Use built-in AI capabilities first:** Analyze and research directly, then generate the A–J table. Treat scripts in this package as optional aids rather than dependencies. Python and `openpyxl` are optional for programmatic XLSX output and validation; they do **not** make AI research calls.
- **If browsing is unavailable:** Complete source-preserving structuring, practical interpretation and qualified draft based on supplied evidence, but explicitly identify claims that could not be externally checked. Do not pretend to have researched current websites or social accounts.
- **If spreadsheet export is unavailable:** Provide the exact A–J rows as a copyable table or CSV instead of pretending a downloadable workbook was made. Native online-sheet comments still need destination verification.
- **Installation, copy-paste prompt and capability matrix:** Read `references/no-api-quickstart.md`.

## Workflow

For Meta lead exports or revisions of an existing batch, read [Meta 线索导出与背调工作流](references/meta-export-workflow.md). It covers matching IDs to original forms, writing sales-ready profiles, and checking grouped Excel delivery.

For every Meta export, apply the linked name and identity marks, then reopen the saved file and check every row against the matched source and research evidence. Channel identity and its customer name use red together. A priority name uses red and bold. For hospitality, red identity and name require a confirmed chain association. Explicit quantities of at least six units use independent red bold emphasis. Complete the [row-by-row checks](references/meta-export-workflow.md) before delivery.

1. **Preserve source** — Parse XLSX/CSV/Markdown/Meta form data (use `scripts/parse_leads.py`). Retain source lead ID, raw choices, exact product interests, quantities, time window, original country, meeting preference and contact channels separately. Never turn `1–5 units, <3 months` into “1–5 monthly” or translate an online-information request into a booth appointment. Deduplicate only by reliable ID.
2. **Investigate proactively** — Search exact organization and contact name, local-language variants, business domain, phone/contact signals, public company registries and owned social links. Explore credible same-name business and professional connections, company operating footprint, vertical and distribution opportunities. Go beyond the form; use first-party websites, social pages and public professional records where possible. Check `references/research-standard.md`.
3. **Synthesize positively** — In D lead with **主营**, then write a short, grounded observation about the company's business background, operating model, footprint or channels. Keep material identity uncertainty to one short qualifier. Put search queries, discarded matches and evidence details in a D note. H handles equipment fit and procurement opportunity. See `references/writing-and-ranking.md`.
4. **Assess buying opportunity** — Preserve original intent in E; use H for business-fit, actual product/application value, scale or channel direction and partnership path. Use I for calibrated P1/P2/P3/待核实, J for one specific forward action. Avoid formulaic sales promises, generic VIP invitations, invented discounts, and dumping `multiple_categories_/_need_selection_advice` into narrative.
5. **Export the fixed A–J format** — The accepted **10-column visible research schema** is: `A 分配业务员 | B 客户信息 | C 国家 | D 公司介绍（主营·背景·规模） | E 原始采购需求 | F 联系方式 / WhatsApp | G 官网与社媒 | H 匹配与合作潜力 | I 背调评级 | J 开发切入点`. **Do not export 8/9 columns or move contacts into the company field**. Phone/email/WA stay together in F; websites and socials together in G. C contains country names only, never dial-code remarks. See `references/output-contract.md`.
6. **Existing master safe-mode** — Inspect exact template headers and preserve downstream K–U (owner feedback/dropdowns/formulas/comments), other tabs, dashboard charts, styles and colors. If template differs from A–J, stop rather than blindly paste. Append by mapped fields and stable lead IDs, not positional guessing. No extra V–AC contact-link columns unless the user explicitly requests an alternative schema. Do not overwrite existing rows or sheet structures; read `references/online-sheet-compatibility.md`.
   For standalone DingTalk handoffs where comments do not carry over, keep A–J and offer the optional plain-text K note from the online-sheet reference. This is a delivery column, separate from existing CRM fields.
7. **Validate and deliver** — Reopen the saved file and validate all product tabs, full filters, frozen headings and identifying columns, notes, external link targets, original demand and counts. For template append run `scripts/append_to_template.py --help` and its checks. Verify destination-native comments separately when delivering through an online sheet.

## Style and integrity rules

- **Information density before caveats:** use useful people/company background, regional market position, procurement context and realistic channel/usage opportunities. A clear business hypothesis is useful when *grounded*; do not present it as verified corporate fact.
- Company profile is segmented and concise enough to scan; do not write placeholder strings such as “company unverified” as the entire profile. Leave scale blank when absent or discuss plausible project size in H rather than manufacturing numbers in D.
- Do not infer nationality from telephone prefix. Country C reflects user-supplied country or grounded geographic identity; ambiguous conflicts go in a comment, not appended to C.
- One F cell holds phone, WhatsApp attempt link (when appropriate), email; one G cell holds URLs for website and socials. In standard XLSX each cell can carry **one clickable hyperlink**; other URLs remain copyable. Do not falsely label all URL strings independently clickable or create Facebook Messenger URLs from lead IDs.
- Preserve business-owner colors and mark exhibition visit intention where template expects it, without claiming a confirmed appointment.
- Existing CRM may also include a supplier-specific fit column outside A–J. **Leave such columns untouched unless the user supplies mapping and explicitly asks to populate it**. Never hard-code a vendor name or product range.
- Never publish real lead IDs, contacts, email addresses, API secrets, proprietary templates or customer spreadsheets to GitHub. Public examples remain fictional and free-tool-compatible.

## Utilities (optional — no third-party API required)

```bash
python scripts/parse_leads.py --input examples/sample_leads.csv --output /tmp/leads.json
python scripts/export_xlsx.py --input examples/sample_research.json --output /tmp/research.xlsx
python scripts/validate_export.py --input /tmp/research.xlsx
python scripts/append_to_template.py --template master.xlsx --input researched.json --output updated.xlsx
python -m unittest discover -s tests -v
```

Tools format **already researched** JSON; they do not conduct web research automatically. The accepted template and all source fields are defined in `references/output-contract.md`.

## Optional usage feedback / 可选使用反馈

After delivering a completed task, you may append one brief, optional invitation in the user's language: “If this skill helped, you can [share usage feedback](https://github.com/RonnyMa-67/RonnyMa/issues/new?template=skill-usage.yml&title=%5B%E4%BD%BF%E7%94%A8%E5%8F%8D%E9%A6%88%5D%20Ronny%20Scout).” Show it at most once per conversation; omit it when the user wants only the deliverable or the task remains incomplete. Feedback is never required to use the skill. Do not open, submit, or transmit feedback automatically; the user chooses whether to follow the link and what to share. GitHub issues are public: do not include customer lists, lead details, campaign/account data, credentials or private work artifacts.

